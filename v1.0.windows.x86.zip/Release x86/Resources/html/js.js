﻿//js.js last modified 2016-11-08
function MadeByJinHoShin(){
	// Silhouette.Draw 함수 drawTarget 이미지표시대상 scriptData 스크립트내용 viewType 1이면픽셀밀접도없이원본 없으면픽셀밀접도고려한고해상도
	this.Draw=function(drawTarget,scriptData,viewType){

		if(!viewType){
			var studiomode=false;
		}
		else if(viewType.indexOf("Test")>-1){
			var studiomode=true;
		}
		else{
			var studiomode=false;
		}

		var studiolog="";
		var tt=document.createElement("textarea");
		var regulated;
		var securityCode="<square.dothome.co.kr/silhouette>";
		// scriptData 스크립트 대상이 object 면 값추출, string 이면 바로 이용
		typeof(scriptData)!="string"?scriptData=scriptData.value:scriptData;
		scriptData=scriptData.replace(/α/gi,"a").replace(/φ/gi,"g").replace(/π/gi,"p").replace(/×/gi,"*").replace(/÷/gi,"/").replace(/√2/gi,"r").replace(/√3/gi,"t");
		// 실루엣스크립트인지 확인
		if(scriptData.split(securityCode).length>1){
			// regulated 정돈된 스크립트 내용
			tt.value=scriptData.substring(scriptData.indexOf(securityCode));
			if(studiomode)studiolog=scriptData.substring(0,scriptData.indexOf(securityCode))+"<".Visual("sg")+"square.dothome.co.kr".Visual("pink")+"/".Visual("")+"silhouette".Visual("red")+">".Visual("sg")+scriptData.substring(securityCode.length+scriptData.indexOf(securityCode)).split("\n")[0].Visual("green")+"<br>";
			regulated=tt.value;
			if(regulated.split("\n")[0].split(securityCode)[1].toLowerCase().Split("v")[1].indexOf("1.0")>-1){
				regulated=regulated.substring(regulated.indexOf("\n")+1);
				// 탭키로 인한 공백 지우기
				var pos=regulated.indexOf("	");
				while(pos>-1){
	 				regulated=regulated.replace("	","");
					pos=regulated.indexOf("	");
				}
			}
			else{
				// 실루엣스크립트 버전이 다를 경우
				if(studiomode)studiolog+=regulated.substring(regulated.indexOf("\n")+1).Visual();
				regulated="";
			}
		}
		else{
			// 실루엣스크립트 확인 문구가 없을 경우
			if(studiomode)studiolog=scriptData.Visual();
			regulated="";
		}

		// mm 시리즈는 절대적인 크기, max 시리즈는 가변적인 레이어 크기
		var mm_x=256;
		var mm_y=256;
		var max_x=256;
		var max_y=256;

		// 뷰타입에 Absolute없으면 해상도 맞게 dpi 조정
		if(!viewType){
			var dpi=window.devicePixelRatio;
		}
		// 뷰타입에 Absolute있으면 dpi 1로 고정 >> 고해상도기기에선 품질저하 속도개선
		else if(viewType.indexOf("Absolute")>-1){
			var dpi=1;
		}
		// 뷰타입에 Absolute없으면 해상도 맞게 dpi 조정
		else{
			var dpi=window.devicePixelRatio;
		}

		// 중간정도
		if(!viewType){
			var radiusQuality=0.1;
		}
		// 곡선이 딱딱하지만 극도로 빠름
		else if(viewType.indexOf("Extreme")>-1){
			var radiusQuality=0.5;
		}
		// 곡선이 덜부드럽지만 속도개선
		else if(viewType.indexOf("Quick")>-1){
			var radiusQuality=0.2;
		}
		// 곡선이 부드럽지만 느림
		else if(viewType.indexOf("Soft")>-1){
			var radiusQuality=0.05;
		}
		// 곡선이 호화롭게 부드럽지만 자원을 많이 사용해서 매우 느림
		else if(viewType.indexOf("Noble")>-1){
			var radiusQuality=0.02;
		}
		// 중간정도
		else{
			var radiusQuality=0.1;
		}

		// 드로타겟이 캔버스면 그 캔버스 사용
		if(drawTarget.nodeName=="CANVAS"){
			var cf=drawTarget;
			drawTarget.style.width=mm_x;
			drawTarget.style.height=mm_y;
		}
		// 다른 경우엔 캔버스 임시생성
		else{
			var cf=document.createElement("canvas");
			drawTarget.style.width=mm_x;
			drawTarget.style.height=mm_y;
		}

		// 캔버스 데이터 가져오고 비워둠
		var ctx=cf.getContext("2d");
		ctx.clearRect(0,0,cf.width,cf.height);
		// 캔버스 크기 설정
		ctx.canvas.width=mm_x*dpi;
		ctx.canvas.height=mm_y*dpi;

		// prev 시리즈는 이전 위치, mg 시리즈는 캔버스 위치, twst 는 캔버스 회전각도
		var prev_x=0;
		var prev_y=0;
		var mg_x=0;
		var mg_y=0;
		var twst=0;

		var CheckGrad=function(dfs){
			if(Silhouette.Grads.indexOf("gradient_"+dfs)==-1){
				return dfs;
			}
			else{
				return eval("gradient_"+dfs);
			}
		}

		// 전체 스크립트를 해석하고 기록한 데이터 배열
		var datad=[];

		var datad_g=[];

		var datadi=[];
		// 레이어 번호 기록한 데이터 배열
		var layline=[];
		// 스튜디오 전용
		var studioline=[];

		var dotted=function(i,spe){
			if(regulated.split("\n")[i].replace(/^ */gi,"").substring(0,1).indexOf(copylayer.substring(0,1))>-1&&regulated.split("\n")[i].indexOf(copylayer.substring(1))>-1){
				// 레이어 복제
				if((regulated.split("\n")[i].replace(/^ */gi,"").substring(regulated.split("\n")[i].indexOf(copylayer.substring(1))+1,regulated.split("\n")[i].length).indexOf(",")>-1||regulated.split("\n")[i].substring(regulated.split("\n")[i].indexOf(copylayer.substring(1))+1,regulated.split("\n")[i].length)<0||regulated.split("\n")[i].substring(regulated.split("\n")[i].indexOf(copylayer.substring(1))+1,regulated.split("\n")[i].length)>=0)&&regulated.split("\n")[i].substring(regulated.split("\n")[i].indexOf(copylayer.substring(1))+1,regulated.split("\n")[i].length).replace(/ /gi,"").length!=0){
					var tim=regulated.split("\n")[i].replace(/^ */gi,"").substring(1,regulated.split("\n")[i].replace(/^ */gi,"").indexOf(copylayer.substring(1)));
					var tim2=regulated.split("\n")[i].replace(/^ */gi,"").substring(regulated.split("\n")[i].replace(/^ */gi,"").indexOf(copylayer.substring(1))+1,regulated.split("\n")[i].replace(/^ */gi,"").length);

					if(typeof(spe)=="object"){
						datadi.push(0);
						studioline[spe[5]]++;
					}
					else{
						datadi.push([tim.Split(",")[0],tim.Split(",")[1],tim.Split(",")[2],tim.Split(",")[3],tim.Split(",")[4],tim.Last(",",5)]);
						if(studiomode)studiolog+=/^ */gi.exec(regulated.split('\n')[i])[0].replace(/ /gi,"&nbsp;")+"[".Visual("pink bg")+tim.substring(0,tim.length-tim.Last(",",5).length).Math().Visual("blue").Math2().replace(/,/gi,"<font class='black'>,</font>")+tim.Last(",",5).Visual("green").Color()+"]".Visual("pink bg")+tim2.Visual("green").replace(/,/gi,"<font class='black'>,</font>")+"<br>";
						studioline[i]++;

						var phmph=(tim.Last(",",5).length<1?0:-1);
						if(i>layline[layline.length-1]||layline.length==0)layline.push(i);
						for(var j=0;j<tim2.split(",").length;j++){
							if(layline.length>tim2.split(",")[j]-(-1)){
								var mola=layline[tim2.split(",")[j]-(-1)];
								for(var k=layline[tim2.split(",")[j]-0]-(phmph);k<mola;k++){
									dotted(k,[tim.Split(",")[0],tim.Split(",")[1],tim.Split(",")[2],tim.Split(",")[3],tim.Split(",")[4],i]);
								}
								datadi.push(0);
								if(typeof(spe)=="object"){
									studioline[spe[5]]++;
								}
								else{
									studioline[i]++;
								}
							}
						}
					}
				}
				// 새 레이어
				else{
					var tim=regulated.split("\n")[i].replace(/^ */gi,"").substring(1,regulated.split("\n")[i].replace(/^ */gi,"").indexOf(copylayer.substring(1)));
					var tim2=regulated.split("\n")[i].replace(/^ */gi,"").substring(regulated.split("\n")[i].replace(/^ */gi,"").indexOf(copylayer.substring(1))+1,regulated.split("\n")[i].replace(/^ */gi,"").length);

					if(typeof(spe)=="object"){
						datadi.push([spe[0],spe[1],spe[2],spe[3],spe[4],tim.Last(",",5)]);
						studioline[spe[5]]++;
					}
					else{
						datadi.push([tim.Split(",")[0],tim.Split(",")[1],tim.Split(",")[2],tim.Split(",")[3],tim.Split(",")[4],tim.Last(",",5)]);
						if(studiomode)studiolog+=/^ */gi.exec(regulated.split('\n')[i])[0].replace(/ /gi,"&nbsp;")+"[".Visual("pink bg")+tim.substring(0,tim.length-tim.Last(",",5).length).Math().Visual("blue").Math2().replace(/,/gi,"<font class='black'>,</font>")+tim.Last(",",5).Visual("green").Color()+"]".Visual("pink bg")+tim2.Visual()+"<br>";
						studioline[i]++;
						if(i>layline[layline.length-1]||layline.length==0)layline.push(i);
					}
				}
			}
			// 글자
			else if(regulated.split("\n")[i].replace(/^ */gi,"").substring(0,1).indexOf(newtext.substring(0,1))>-1&&regulated.split("\n")[i].indexOf(newtext.substring(1))>-1){
				var tim=regulated.split("\n")[i].replace(/^ */gi,"").substring(1,regulated.split("\n")[i].replace(/^ */gi,"").indexOf(newtext.substring(1)));
				var tim2=regulated.split("\n")[i].replace(/^ */gi,"").substring(regulated.split("\n")[i].replace(/^ */gi,"").indexOf(newtext.substring(1))+1,regulated.split("\n")[i].replace(/^ */gi,"").length);

				datadi.push([tim.Split(",")[0],tim.Split(",")[1],tim.Split(",")[2],[tim.Split(",")[3],tim.Split(",")[4]],tim2]);
				if(typeof(spe)=="object"){
					studioline[spe[5]]++;
				}
				else{
					if(studiomode)studiolog+=/^ */gi.exec(regulated.split('\n')[i])[0].replace(/ /gi,"&nbsp;")+"<".Visual("pink")+tim.substring(0,tim.length-tim.Last(",",3).length).Math().Visual("blue").Math2().replace(/,/gi,"<font class='black'>,</font>")+tim.Last(",",3).Visual("green").Color().replace(/,/gi,"<font class='black'>,</font>")+">".Visual("pink")+tim2.Visual("black")+"<br>";
					studioline[i]++;
				}
			}
			// 점
			else if(regulated.split("\n")[i].replace(/^ */gi,"").split(",").length==2){
				var tim=regulated.split("\n")[i].replace(/^ */gi,"");

				datadi.push([tim.Split(",")[0],tim.Split(",")[1]]);
				if(typeof(spe)=="object"){
					studioline[spe[5]]++;
				}
				else{
					if(studiomode)studiolog+=/^ */gi.exec(regulated.split('\n')[i])[0].replace(/ /gi,"&nbsp;")+tim.Math().Visual("blue").Math2().replace(/,/gi,"<font class='black'>,</font>")+"<br>";
					studioline[i]++;
				}
			}
			// 곡선 중심
			else if(regulated.split("\n")[i].replace(/^ */gi,"").split(",").length==3){
				var tim=regulated.split("\n")[i].replace(/^ */gi,"");

				datadi.push([tim.Split(",")[0],tim.Split(",")[1],tim.Split(",")[2]]);
				if(typeof(spe)=="object"){
					studioline[spe[5]]++;
				}
				else{
					if(studiomode)studiolog+=/^ */gi.exec(regulated.split('\n')[i])[0].replace(/ /gi,"&nbsp;")+tim.Math().Visual("blue").Math2().replace(/,/gi,"<font class='black'>,</font>")+"<br>";
					studioline[i]++;
				}
			}
			else{
				var tim=regulated.split("\n")[i];

				datadi.push(0);
				if(typeof(spe)=="object"){
					studioline[spe[5]]++;
				}
				else{
					if(studiomode)studiolog+=tim.Visual()+"<br>";
					studioline[i]++;
				}
			}
		}

		// 주석, 레이어, 복제, 그라데이션, 헤더, 이미지크기 데이터 구분자
		var annotation="//";
		var newlayer="[]";
		var copylayer="[]";
		var setgradient="#";
		var addgradient="*";
		var newtext="<>";
		var addheader="+";
		var imagesize="@";

		// i 는 몇번째줄인지 기억
		for(var i=0;i<regulated.split("\n").length;i++){
			studioline[i]=0;
			// 공란인 경우
			if(regulated.split("\n")[i].length<1){
				datadi.push(0);
				if(studiomode)studiolog+="<br>";
				studioline[i]++;
			}
			// 주석인 경우
			else if(regulated.split("\n")[i].replace(/^ */gi,"").substring(0,2).indexOf(annotation)>-1){
				var tim=regulated.split("\n")[i].replace(/^ */gi,"").substring(2);
				datadi.push(0);
				if(studiomode)studiolog+=/^ */gi.exec(regulated.split('\n')[i])[0].replace(/ /gi,"&nbsp;")+("//"+tim).Visual("green")+"<br>";
				studioline[i]++;
			}
			// 헤더파일인 경우
			else if(regulated.split("\n")[i].replace(/^ */gi,"").substring(0,1).split(addheader).length==2){
				var tim=regulated.split("\n")[i].replace(/^ */gi,"").substring(1);
				var Fileref=document.createElement("link");
				Fileref.setAttribute("rel","stylesheet");
				Fileref.setAttribute("type","text/css");
				Fileref.setAttribute("href",tim);
				document.getElementsByTagName("head")[0].appendChild(Fileref);
				datadi.push(0);
				if(studiomode)studiolog+=/^ */gi.exec(regulated.split('\n')[i])[0].replace(/ /gi,"&nbsp;")+"+".Visual("pink")+tim.Visual("green")+"</font><br>";
				studioline[i]++;
			}
			// 캔버스 크기
			else if(regulated.split("\n")[i].replace(/^ */gi,"").substring(0,1).split(imagesize).length==2){
				var tim=regulated.split("\n")[i].replace(/^ */gi,"").substring(1);
				var iw1=eval(tim.Split(",")[0]-0);
				var ih1=eval(tim.Split(",")[1]-0);
				if(iw1>0){
				}
				else{
					iw1=256;
				}
				if(ih1>0){
				}
				else{
					ih1=256;
				}
				datadi.push(0);
				if(studiomode)studiolog+=/^ */gi.exec(regulated.split('\n')[i])[0].replace(/ /gi,"&nbsp;")+"@".Visual("pink")+tim.Visual("blue").replace(/,/gi,"<font class='black'>,</font>")+"<br>";
				studioline[i]++;

				mm_x=eval(iw1);
				mm_y=eval(ih1);
				max_x=eval(iw1);
				max_y=eval(ih1);
				ctx.canvas.width=mm_x*dpi;
				ctx.canvas.height=mm_y*dpi;
				if(drawTarget.nodeName=="DIV"){
				}
				else{
					drawTarget.style.width=mm_x;
					drawTarget.style.height=mm_y;
				}
			}
			// 그라데이션 설정
			else if(regulated.split("\n")[i].replace(/^ */gi,"").substring(0,1).split(setgradient).length==2){
				var tim=regulated.split("\n")[i].replace(/^ */gi,"").substring(1);
				var inm=tim.Split(",")[0];
				var ix1=tim.Split(",")[1];
				var iy1=tim.Split(",")[2];
				var ix2=tim.Split(",")[3];
				var iy2=tim.Split(",")[4];
				ix1.length==0?ix1="0":true;
				iy1.length==0?iy1="0":true;
				ix2.length==0?ix2="100%":true;
				iy2.length==0?iy2="100%":true;
				datad_g.push([inm.replace(/[^0-9a-zA-Z_$]/gi,""),ix1,iy1,ix2,iy2]);
				if(studiomode)studiolog+=/^ */gi.exec(regulated.split('\n')[i])[0].replace(/ /gi,"&nbsp;")+"#".Visual("pink")+inm.Visual("green")+tim.substring(inm.length).Math().Visual("blue").Math2().replace(/,/gi,"<font class='black'>,</font>")+"<br>";

				datadi.push(0);
				studioline[i]++;
			}
			// 그라데이션 요소
			else if(regulated.split("\n")[i].replace(/^ */gi,"").substring(0,1).split(addgradient).length==2){
				var tim=regulated.split("\n")[i].replace(/^ */gi,"").substring(1);
				var ix=tim.Split(",")[0];
				var ib=tim.Last(",",1);
				datad_g.push([ix,ib]);
				if(studiomode)studiolog+=/^ */gi.exec(regulated.split('\n')[i])[0].replace(/ /gi,"&nbsp;")+"*".Visual("pink")+ix.Math().Visual("blue").Math2()+tim.substring(ix.length).Visual("green").replace(/,/gi,"<font class='black'>,</font>").Color()+"<br>";

				datadi.push(0);
				studioline[i]++;
			}
			else{
				dotted(i);
			}
		}
		if(!studiomode){
			ctx.globalCompositeOperation="source-over";
			ctx.fillStyle="#aaaaaa";

			regulated=scriptData;

			function vot(i,j){
				if(j==2){
					prev_x=0;
					prev_y=0;
					var xi=eval(datadi[i][0].replace(/g/gi,"1.61803").replace(/r/gi,"1.4142135").replace(/t/gi,"1.7320508").replace(/%/gi,"*mm_x/100"));
					var yi=eval(datadi[i][1].replace(/g/gi,"1.61803").replace(/r/gi,"1.4142135").replace(/t/gi,"1.7320508").replace(/%/gi,"*mm_y/100"));
					var iw1=datadi[i][2].length==0?mm_x:eval(datadi[i][2].replace(/g/gi,"1.61803").replace(/r/gi,"1.4142135").replace(/t/gi,"1.7320508").replace(/%/gi,"*mm_x/100"));
					var ih1=datadi[i][3].length==0?mm_y:eval(datadi[i][3].replace(/g/gi,"1.61803").replace(/r/gi,"1.4142135").replace(/t/gi,"1.7320508").replace(/%/gi,"*mm_y/100"));
					var it1=datadi[i][4].length==0?0:eval(datadi[i][4].replace(/p/gi,"Math.PI"));
					mg_x=xi;
					mg_y=yi;
					max_x=iw1;
					max_y=ih1;
					twst=it1;
					datad[i]=[xi,yi,iw1,ih1,it1,datadi[i][5]];
				}
				else{
					var xi=datadi[i][0];
					var yi=datadi[i][1];
					var prev_xi=eval(xi.replace(/g/gi,"1.61803").replace(/r/gi,"1.4142135").replace(/t/gi,"1.7320508").replace(/a/gi,"prev_x").replace(/%/gi,"*max_x/100"));
					var prev_yi=eval(yi.replace(/g/gi,"1.61803").replace(/r/gi,"1.4142135").replace(/t/gi,"1.7320508").replace(/a/gi,"prev_y").replace(/%/gi,"*max_y/100"));
					if(twst!=0&&!(prev_xi==0&&prev_yi==0)){
						var thi=Math.atan(prev_yi/prev_xi)+twst;
						prev_xi>=0?thi+=0:thi+=Math.PI;
						xi=Math.cos(thi)*Math.sqrt(Math.pow(prev_xi,2)+Math.pow(prev_yi,2));
						yi=Math.sin(thi)*Math.sqrt(Math.pow(prev_xi,2)+Math.pow(prev_yi,2));
						xi+=mg_x+Math.sqrt(Math.pow(max_x,2)+Math.pow(max_y,2))*Math.sin(twst/2)*Math.cos((Math.PI-twst)/2-Math.atan(max_y/max_x));
						yi+=mg_y-Math.sqrt(Math.pow(max_x,2)+Math.pow(max_y,2))*Math.sin(twst/2)*Math.sin((Math.PI-twst)/2-Math.atan(max_y/max_x));
					}
					else if(twst!=0&&(prev_xi==0&&prev_yi==0)){
						var thi=Math.atan(prev_yi/prev_xi)+twst;
						prev_xi>=0?thi+=0:thi+=Math.PI;
						xi=prev_xi;
						yi=prev_yi;	
						xi+=mg_x+Math.sqrt(Math.pow(max_x,2)+Math.pow(max_y,2))*Math.sin(twst/2)*Math.cos((Math.PI-twst)/2-Math.atan(max_y/max_x));
						yi+=mg_y-Math.sqrt(Math.pow(max_x,2)+Math.pow(max_y,2))*Math.sin(twst/2)*Math.sin((Math.PI-twst)/2-Math.atan(max_y/max_x));
					}
					else{
						xi=prev_xi+mg_x;
						yi=prev_yi+mg_y;
					}
					if(j==1){datad[i]=[xi,yi];}
					else{prev_x=prev_xi;prev_y=prev_yi;datad[i]=[xi,yi];}
				}
			}

			var i=0;

			var cnm="";
			var cx1="";
			var cy1="";
			var cx2="";
			var cy2="";
			for(var i=0;i<datad_g.length;i++){
				if(datad_g[i].length==2){
					var ix=eval(datad_g[i][0].replace(/g/gi,"1.61803").replace(/r/gi,"1.4142135").replace(/t/gi,"1.7320508").replace(/%/gi,"*Math.sqrt(Math.pow(cx2-cx1,2)+Math.pow(cy2-cy1,2))/100"))/Math.sqrt(Math.pow(cx2-cx1,2)+Math.pow(cy2-cy1,2));
					var ib=datad_g[i][1];
					eval("gradient_"+cnm+".addColorStop("+ix+",'"+ib+"')");
				}
				else if(datad_g[i].length==5){
					cnm=datad_g[i][0];
					cx1=eval(datad_g[i][1].replace(/g/gi,"1.61803").replace(/r/gi,"1.4142135").replace(/t/gi,"1.7320508").replace(/%/gi,"*mm_x/100"))*dpi;
					cy1=eval(datad_g[i][2].replace(/g/gi,"1.61803").replace(/r/gi,"1.4142135").replace(/t/gi,"1.7320508").replace(/%/gi,"*mm_y/100"))*dpi;
					cx2=eval(datad_g[i][3].replace(/g/gi,"1.61803").replace(/r/gi,"1.4142135").replace(/t/gi,"1.7320508").replace(/%/gi,"*mm_x/100"))*dpi;
					cy2=eval(datad_g[i][4].replace(/g/gi,"1.61803").replace(/r/gi,"1.4142135").replace(/t/gi,"1.7320508").replace(/%/gi,"*mm_y/100"))*dpi;
					if(eval("typeof(gradient_"+cnm+")")=="undefined"){
						Silhouette.SetGrad("gradient_"+cnm);
						eval("var gradient_"+cnm+"=ctx.createLinearGradient("+cx1+","+cy1+","+cx2+","+cy2+")");
					}
				}
			}
			var nd=0;
			for(var i=0;i<datadi.length;i++){
				nd=0;
				ctx.beginPath();
				if(datadi.length>i){
					while(i<datadi.length){
						if(datadi[i]==-1){
							datad[i]=datadi[i];
							break;
						}
						else if(datadi[i]==0){
							datad[i]=datadi[i];
							break;
						}
						// 숫자
						else if(datadi[i]>=1){
							datad[i]=datadi[i];
							if(i>=datad[i])i++;
							else i=datad[i];
						}
						// 점
						else if(datadi[i].length==2){
							vot(i);
							if(nd==0){
								ctx.moveTo((datad[i][0])*dpi,(datad[i][1])*dpi);
								nd=1;
							}
							else{
								ctx.lineTo((datad[i][0])*dpi,(datad[i][1])*dpi);
							}
							i++;
						}
						// 곡선의 중심
						else if(datadi[i].length==3){
							vot(i);
							vot(i+1,1);
							var ir1=datadi[i][2]-0;
							(ir1>0||ir1<=0)?true:ir1=0;
							datad[i][2]=ir1;
							if(datad[i][0]==datad[i-1][0]){
								var ipr=(datad[i][1]-datad[i-1][1]>=0)?Math.PI/2:-Math.PI/2;
							}
							else if(datad[i][0]>datad[i-1][0]){
								var ipr=Math.atan(-(datad[i][1]-datad[i-1][1])/(datad[i][0]-datad[i-1][0]))+Math.PI;
							}
							else if(datad[i][0]<datad[i-1][0]){
								var ipr=Math.atan(-(datad[i][1]-datad[i-1][1])/(datad[i][0]-datad[i-1][0]));
							}

							if(datad[i][0]==datad[i+1][0]){
								var ine=(datad[i+1][1]-datad[i][1]>=0)?-Math.PI/2:Math.PI/2;
							}
							else if(datad[i][0]>datad[i+1][0]){
								var ine=Math.atan(-(datad[i][1]-datad[i+1][1])/(datad[i][0]-datad[i+1][0]))+Math.PI;
							}
							else if(datad[i][0]<datad[i+1][0]){
								var ine=Math.atan(-(datad[i][1]-datad[i+1][1])/(datad[i][0]-datad[i+1][0]));
							}

							while(ine-ipr<0||ine-ipr>2*Math.PI){
								if(ine-ipr<0)ine+=2*Math.PI;
								if(ine-ipr>=2*Math.PI)ine-=2*Math.PI;
							}

							if(datad[i][2]==-1){
								if(ine-ipr==0)ine+=2*Math.PI;
							}
							else{
								ine-=2*Math.PI;
							}

							var radiusd1=Math.sqrt(Math.pow((datad[i][0]-datad[i-1][0]),2)+Math.pow((datad[i][1]-datad[i-1][1]),2));

							var radiusd2=Math.sqrt(Math.pow((datad[i][0]-datad[i+1][0]),2)+Math.pow((datad[i][1]-datad[i+1][1]),2));

							var max_j=Math.round(Math.abs(ipr-ine)/radiusQuality);

							for(var j=1;j<max_j;j++){
								ctx.lineTo(((datad[i][0]+(radiusd1*(max_j-j)+radiusd2*j)/max_j*Math.cos(ipr+(ine-ipr)/max_j*j)))*dpi,((datad[i][1]-(radiusd1*(max_j-j)+radiusd2*j)/max_j*Math.sin(ipr+(ine-ipr)/max_j*j)))*dpi);
							}
							i++;
						}
						// 글자
						else if(datadi[i].length==5){
							var xi=0;
							var yi=0;
							prev_x=eval(datadi[i][0].replace(/g/gi,"1.61803").replace(/r/gi,"1.4142135").replace(/t/gi,"1.7320508").replace(/a/gi,"prev_x").replace(/%/gi,"*max_x/100"));
							prev_y=eval(datadi[i][1].replace(/g/gi,"1.61803").replace(/r/gi,"1.4142135").replace(/t/gi,"1.7320508").replace(/a/gi,"prev_y").replace(/%/gi,"*max_y/100"));
							var si=eval(datadi[i][2].replace(/g/gi,"1.61803").replace(/r/gi,"1.4142135").replace(/t/gi,"1.7320508").replace(/%/gi,"*max_y/100"));
							xi=prev_x+mg_x;
							yi=prev_y+mg_y-(-si);

							datad[i]=[xi,yi,(si*dpi)+"px "+datadi[i][3][0],datadi[i][4],datadi[i][3][1]];
							ctx.closePath();
							ctx.fill();
							nd=0;
							ctx.font=datad[i][2];
							ctx.textAlign="left";
							if(datad[i][4].split("eraser").length>1){
								ctx.globalCompositeOperation="destination-out";
							}
							else if(datad[i][4].split("cutter").length>1){
								ctx.globalCompositeOperation="destination-in";
							}
							else{
								ctx.globalCompositeOperation="source-over";
								ctx.fillStyle=CheckGrad(datad[i][4],ctx);
							}
							ctx.fillText(datad[i][3],(datad[i][0])*dpi,(datad[i][1])*dpi);
							ctx.beginPath();
							i++;
						}
						// 새 레이어
						else if(datadi[i].length==6){
							vot(i,2);
							ctx.closePath();
							ctx.fill();
							nd=0;
							ctx.beginPath();
							if(datad[i][5].split("eraser").length>1){
								ctx.globalCompositeOperation="destination-out";
							}
							else if(datad[i][5].split("cutter").length>1){
								ctx.globalCompositeOperation="destination-in";
							}
							else if(datad[i][5].length==0){
							}
							else{
								ctx.globalCompositeOperation="source-over";
								ctx.fillStyle=CheckGrad(datad[i][5],ctx);
							}
							i++;
						}
					}
				}
				ctx.closePath();
				ctx.fill();

				ctx.globalCompositeOperation="source-over";
			}
			ctx.restore();

			if(drawTarget.nodeName=="CANVAS"){
			}
			else if(drawTarget.nodeName=="IMG"){
				drawTarget.src=cf.toDataURL();
			}
			else{
				drawTarget.style.backgroundImage="url("+cf.toDataURL()+")";
				drawTarget.style.backgroundSize="100% 100%";
				drawTarget.style.backgroundRepeat="no-repeat";
			}
			Silhouette.Grads=new Array();
			return [datad,studioline,layline,cf.toDataURL()];
		}
		else{
			Silhouette.Grads=new Array();
			return studiolog;
		}
	}

	// Silhouette.SetGrad 함수
	this.SetGrad=function(dfs){
		Silhouette.Grads.push(dfs);
	}

	// Silhouette.Grads 배열
	this.Grads=new Array();
}


String.prototype.Visual=function(vd){
	if(vd==undefined){
		return this.replace(/</gi,"&lt;").replace(/>/gi,"&gt;").replace(/\n/gi,"<br>").replace(/ /gi,"&nbsp;").replace(/"/gi,"&quot;");
	}
	else{
		return "<font class='"+vd+"'>"+this.replace(/</gi,"&lt;").replace(/>/gi,"&gt;").replace(/\n/gi,"<br>").replace(/ /gi,"&nbsp;").replace(/"/gi,"&quot;")+"</font>";
	}
};
String.prototype.Split=function(vd){
	var imsi=this.split(vd);
	for(var t=imsi.length;t<=7;t++){
		imsi.push("");
	}
	return imsi;
};
String.prototype.Last=function(vd,i){
	var imsi=this.split(vd);
	var imsi2="";
	for(var t=i;t<imsi.length;t++){
		imsi2+=imsi[t];
		if(t+1<imsi.length)imsi2+=vd;
	}
	return imsi2;
};
String.prototype.Math=function(){
	return this.replace(/t/gi,"√3").replace(/r/gi,"√2").replace(/g/gi,"φ").replace(/a/gi,"α").replace(/p/gi,"π").replace(/\*/gi,"×").replace(/\//gi,"÷");
};
String.prototype.Math2=function(){
	return this.replace(/\(/gi,"<font class='red'>(</font>").replace(/\)/gi,"<font class='red'>)</font>").replace(/%/gi,"<font class='red'>%</font>").replace(/α/gi,"<font class='red a'>α</font>").replace(/√3/gi,"<font class='red r'>√3</font>").replace(/√2/gi,"<font class='red r'>√2</font>").replace(/φ/gi,"<font class='red g'>φ</font>").replace(/π/gi,"<font class='red p'>π</font>").replace(/\+/gi,"<font class='red'>+</font>").replace(/\-/gi,"<font class='red'>-</font>").replace(/×/gi,"<font class='red'>×</font>").replace(/÷/gi,"<font class='red'>÷</font>");
};
String.prototype.Color=function(){
	return this.replace(/rgba/gi,"<font class='red it'>rgba</font>").replace(/rgb/gi,"<font class='red it'>rgb</font>").replace(/\)/gi,"<font class='red'>)</font>").replace(/\(/gi,"<font class='red'>(</font>").replace(/#/gi,"<font class='red'>#</font>");
};


var Silhouette=new MadeByJinHoShin;